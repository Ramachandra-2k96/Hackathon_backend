# Payments Service

InvoiceService handles invoice lifecycle.

## API

POST /invoices creates invoices.
