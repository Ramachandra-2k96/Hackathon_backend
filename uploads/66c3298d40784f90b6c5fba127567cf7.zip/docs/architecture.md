# Payment Platform Architecture

`GatewayService` receives API requests and forwards to `PaymentOrchestrator`.
`PaymentOrchestrator` calls `RiskEngine` before charging through `StripeAdapter`.
