# Merchant Onboarding

`MerchantService` creates merchant profiles and links them to `KYCWorkflow`.
`KYCWorkflow` uses `DocumentVerifier` and sends final status to `MerchantService`.
