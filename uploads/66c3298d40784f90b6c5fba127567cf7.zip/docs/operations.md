# Incident Operations

`AlertManager` routes severe incidents to `OnCallRunbook`.
`OnCallRunbook` references `GatewayService` health checks and rollback actions.
